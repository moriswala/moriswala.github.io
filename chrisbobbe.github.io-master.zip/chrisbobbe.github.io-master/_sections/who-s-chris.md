---
title: Who's Chris?
icon: fa-question
order: 2
---

<script type="text/javascript" src="assets/js/gem-download-count.js" defer></script>

I'm a front-end web developer!

I'm currently making lots of open-source web templates into Jekyll themes so more people can use them. The theme you're looking at, my [Jekyll version](https://github.com/chrisbobbe/jekyll-theme-prologue) of [Prologue by HTML5 UP](https://html5up.net/prologue), has <a href="https://rubygems.org/gems/jekyll-theme-prologue"><span id="download-counter">[unavailable]</span> gem downloads</a>! I also make intuitive user interfaces with Angular and React. I started coding when I was nine and kept it up through college where I did an English degree. My creative and analytical skills might be a great fit for your project, especially if it means taking something old and clunky and making it shiny, responsive, and accessible.
